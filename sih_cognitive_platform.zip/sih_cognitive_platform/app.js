const app = document.getElementById('app');

const state = {
  role: null,
  gamer: { name: 'Anita', language: 'English', assigned: true },
  caregiver: { name: 'Caregiver' },
  currentLevel: 'normal',
  checkingScore: null,
  lastResult: null,
  gameNumber: 1,
  override: 'ai',
  reminder: 'Take medicine at 8:00 AM',
};

const levels = {
  easy: { label: 'Easy', items: 3, seconds: 15 },
  normal: { label: 'Normal', items: 5, seconds: 10 },
  hard: { label: 'Hard', items: 8, seconds: 6 },
};

const marketItems = [
  { emoji:'🍚', name:'Rice' }, { emoji:'🐟', name:'Fish' }, { emoji:'🥬', name:'Vegetables' },
  { emoji:'🍌', name:'Banana' }, { emoji:'🫖', name:'Tea' }, { emoji:'🥥', name:'Coconut' },
  { emoji:'🌶️', name:'Chilli' }, { emoji:'🥔', name:'Potato' }, { emoji:'🍍', name:'Pineapple' },
];

function render(html) { app.innerHTML = html; }
function levelBadge(level) { return `<span class="badge level-${level}">${levels[level].label}</span>`; }

function login() {
  render(`
    <div class="card login">
      <h1>NER Cognitive Care</h1>
      <p class="small">Basic SIH 2026 prototype — two roles, two-stage adaptive game.</p>
      <div class="tabs">
        <button class="active" onclick="setLoginRole('gamer', this)">Gamer</button>
        <button onclick="setLoginRole('caregiver', this)">Caregiver</button>
      </div>
      <div id="login-form">
        <label>Name</label>
        <input id="login-name" value="Anita" />
        <label>Preferred language</label>
        <select id="login-language">
          <option>English</option><option>Hindi</option><option>Assamese</option><option>Manipuri</option><option>Mizo</option>
        </select>
        <div class="actions"><button class="primary" onclick="doLogin()">Login</button></div>
      </div>
    </div>`);
}

function setLoginRole(role, btn) {
  state.role = role;
  document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('login-name').value = role === 'gamer' ? 'Anita' : 'Caregiver';
}

function doLogin() {
  state.role = state.role || 'gamer';
  const name = document.getElementById('login-name').value.trim() || (state.role === 'gamer' ? 'Anita' : 'Caregiver');
  if (state.role === 'gamer') { state.gamer.name = name; state.gamer.language = document.getElementById('login-language').value; gamerHome(); }
  else { state.caregiver.name = name; caregiverHome(); }
}

function shell(title, body) {
  return `<div class="container"><div class="header"><div><h1>${title}</h1><div class="small">SIH26003 prototype</div></div><button class="secondary" onclick="login()">Logout</button></div>${body}</div>`;
}

function gamerHome() {
  render(shell(`Welcome, ${state.gamer.name}`, `
    <div class="card">
      <div class="header"><div><h2>Today's activity</h2><p class="small">Complete the checking round first. The system then chooses the next difficulty.</p></div>${levelBadge(state.currentLevel)}</div>
      <div class="actions"><button class="primary" onclick="startChecking()">Start Game</button></div>
    </div>
    <div class="grid">
      <div class="stat"><span>Last score</span><strong>${state.lastResult ?? '--'}%</strong></div>
      <div class="stat"><span>Current level</span><strong>${levels[state.currentLevel].label}</strong></div>
      <div class="stat"><span>Reminder</span><strong style="font-size:18px">${state.reminder}</strong></div>
    </div>`));
}

function startChecking() {
  playRound('checking', 'normal');
}

function playRound(mode, forcedLevel) {
  const level = forcedLevel;
  const count = levels[level].items;
  const pool = [...marketItems].sort(() => Math.random() - 0.5).slice(0, count);
  const distractors = marketItems.filter(x => !pool.includes(x)).sort(() => Math.random()-0.5).slice(0, Math.min(4, 9-count));
  const shown = new Set(pool.map(x => x.name));
  let timeLeft = levels[level].seconds;

  render(shell(mode === 'checking' ? 'Game 1 — Checking Round' : 'Game 2 — Adaptive Round', `
    <div class="card">
      <p><strong>${mode === 'checking' ? 'Remember these items.' : `Difficulty: ${levels[level].label}`}</strong></p>
      <p class="small">You have ${levels[level].seconds} seconds to look.</p>
      <progress id="timer" max="${levels[level].seconds}" value="${levels[level].seconds}"></progress>
      <div class="game-grid" style="margin-top:16px">${pool.map(x => `<div class="item">${x.emoji}<div style="font-size:14px;margin-top:5px">${x.name}</div></div>`).join('')}</div>
      <div id="round-next" class="actions hidden"><button class="primary" onclick="showChoices(${JSON.stringify([...shown])}, ${JSON.stringify([...distractors.map(x=>x.name)])}, '${mode}', '${level}')">Continue</button></div>
    </div>`));

  const interval = setInterval(() => {
    timeLeft -= 1;
    const bar = document.getElementById('timer');
    if (bar) bar.value = Math.max(timeLeft,0);
    if (timeLeft <= 0) { clearInterval(interval); document.getElementById('round-next')?.classList.remove('hidden'); }
  }, 1000);
}

function showChoices(correctNames, distractorNames, mode, level) {
  const choices = [...correctNames, ...distractorNames].sort(() => Math.random()-0.5);
  const selected = new Set();
  render(shell(mode === 'checking' ? 'Game 1 — Checking Round' : 'Game 2 — Adaptive Round', `
    <div class="card">
      <h2>Select what you remember</h2>
      <p class="small">Tap the items you saw.</p>
      <div class="game-grid">${choices.map(name => { const x=marketItems.find(i=>i.name===name); return `<button class="choice" data-name="${name}" onclick="toggleChoice(this)">${x.emoji}<div>${name}</div></button>`; }).join('')}</div>
      <div class="actions"><button class="primary" onclick="finishRound(${JSON.stringify(correctNames)}, '${mode}', '${level}')">Submit</button></div>
    </div>`));
}

function toggleChoice(btn) { btn.classList.toggle('selected'); }

function finishRound(correctNames, mode, level) {
  const chosen = [...document.querySelectorAll('.choice.selected')].map(b => b.dataset.name);
  const correct = chosen.filter(x => correctNames.includes(x)).length;
  const wrong = chosen.filter(x => !correctNames.includes(x)).length;
  const exact = correct === correctNames.length && wrong === 0;
  const score = Math.max(0, Math.round((correct / correctNames.length) * 100 - wrong * 10));

  if (mode === 'checking') {
    state.checkingScore = score;
    if (state.override !== 'ai') {
      state.currentLevel = state.override;
    } else if (score < 50) {
      state.currentLevel = 'easy';
    } else if (score > 80) {
      state.currentLevel = 'hard';
    } else {
      state.currentLevel = 'normal';
    }
    state.lastResult = score;
    render(shell('AI Difficulty Decision', `
      <div class="card">
        <h2>Checking result: ${score}%</h2>
        <p>Correct: ${correctNames.filter(x=>chosen.includes(x)).length}/${correctNames.length} &nbsp; | &nbsp; Wrong selections: ${wrong}</p>
        <p>The next game is set to <strong>${levels[state.currentLevel].label}</strong>.</p>
        ${levelBadge(state.currentLevel)}
        <div class="actions"><button class="primary" onclick="playRound('adaptive','${state.currentLevel}')">Start Game 2</button></div>
      </div>`));
  } else {
    state.lastResult = score;
    render(shell('Game Complete', `
      <div class="card">
        <h2>Adaptive round finished</h2>
        <p>Your score: <strong>${score}%</strong></p>
        <p class="small">This score is saved for the caregiver dashboard.</p>
        <div class="actions"><button class="primary" onclick="gamerHome()">Back to Dashboard</button></div>
      </div>`));
  }
}

function caregiverHome() {
  render(shell('Caregiver Dashboard', `
    <div class="grid">
      <div class="stat"><span>Gamer</span><strong>${state.gamer.name}</strong></div>
      <div class="stat"><span>Last score</span><strong>${state.lastResult ?? '--'}%</strong></div>
      <div class="stat"><span>AI level</span><strong>${levels[state.currentLevel].label}</strong></div>
    </div>
    <div class="card">
      <h2>Assign / Control Game</h2>
      <label>Mode</label>
      <select id="mode-select" onchange="setOverride(this.value)">
        <option value="ai" ${state.override==='ai'?'selected':''}>AI Adaptive</option>
        <option value="easy" ${state.override==='easy'?'selected':''}>Fixed — Easy</option>
        <option value="normal" ${state.override==='normal'?'selected':''}>Fixed — Normal</option>
        <option value="hard" ${state.override==='hard'?'selected':''}>Fixed — Hard</option>
      </select>
      <label>Reminder</label>
      <input id="reminder" value="${state.reminder}" />
      <div class="actions"><button class="primary" onclick="saveCaregiverSettings()">Save Settings</button><button class="secondary" onclick="previewGamer()">Open Gamer View</button></div>
    </div>
    <div class="card">
      <h2>Gamer Progress</h2>
      <p>Checking score: <strong>${state.checkingScore ?? '--'}%</strong></p>
      <p>Current game level: ${levelBadge(state.currentLevel)}</p>
      <p class="small">Caregiver has full control. Gamer can view the dashboard but cannot change settings.</p>
    </div>`));
}

function setOverride(value) { state.override = value; }
function saveCaregiverSettings() { state.reminder = document.getElementById('reminder').value || state.reminder; caregiverHome(); }
function previewGamer() { gamerHome(); }

// Default role for prototype login.
state.role = 'gamer';
login();
