# NER Cognitive Care — SIH26003 Basic Prototype

A deliberately simple browser prototype for the SIH 2026 dementia cognitive-gaming concept.

## What is included
- Two logins/roles: Gamer and Caregiver
- Exactly two game stages:
  1. Checking Game
  2. Adaptive Game
- One simple game concept: Market Memory
- AI-like rule engine:
  - score < 50% -> Easy
  - score 50–80% -> Normal
  - score > 80% -> Hard
- Same checking/adaptation cycle can be repeated for each future game
- Caregiver can choose AI Adaptive or fixed difficulty
- Gamer can see progress but cannot change settings
- No backend, no real patient data, no medical diagnosis

## Run
Open `index.html` in a browser.

## Open in Codex
Open the `sih_cognitive_platform` folder as your project/workspace in Codex, then ask Codex to extend it.

Suggested next Codex prompt:
"Improve this prototype without changing the basic flow. Keep exactly two game stages and make the code beginner-friendly."
